import React from 'react'
import events from '../data/events.json'

interface HomePageProps {
  language: string;
  onEventClick: (id: number) => void;
}

const HomePage: React.FC<HomePageProps> = ({ language, onEventClick }) => {
  const translations = {
    en: {
      welcome: "Welcome to Our Art Events Platform",
      description: "Discover amazing art events, connect with creative individuals, and immerse yourself in the world of artistic expression.",
      viewEvent: "View Event"
    },
    zh: {
      welcome: "欢迎来到我们的艺术活动平台",
      description: "发现精彩的艺术活动，与创意人士交流，沉浸在艺术表达的世界中。",
      viewEvent: "查看活动"
    }
  }

  const t = translations[language as keyof typeof translations]

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold text-accent mb-6">{t.welcome}</h1>
      <p className="text-lg text-gray-700 mb-8">
        {t.description}
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {events.map((event) => (
          <FeaturedSection
            key={event.id}
            id={event.id}
            title={language === 'en' ? event.title : event.titleZh || event.title}
            description={language === 'en' ? event.description.split('\n')[0] : event.descriptionZh?.split('\n')[0] || event.description.split('\n')[0]}
            date={event.date}
            linkText={t.viewEvent}
            onEventClick={onEventClick}
          />
        ))}
      </div>
    </div>
  )
}

const FeaturedSection: React.FC<{ id: number; title: string; description: string; date: string; linkText: string; onEventClick: (id: number) => void }> = ({
  id,
  title,
  description,
  date,
  linkText,
  onEventClick,
}) => {
  return (
    <div className="relative overflow-hidden rounded-lg shadow-md h-80">
      <div 
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{ backgroundImage: `url(/bg-${id}.png)` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black z-10"></div>
      <div className="relative h-full flex flex-col justify-end p-6 z-20 text-white">
        <h2 className="text-2xl font-semibold mb-2">{title}</h2>
        <p className="text-sm mb-2">{new Date(date).toLocaleDateString()}</p>
        <p className="text-sm mb-4 line-clamp-2">{description}</p>
        <button
          onClick={() => onEventClick(id)}
          className="inline-block bg-accent text-white px-4 py-2 rounded hover:bg-accent/80 transition-colors duration-200"
        >
          {linkText}
        </button>
      </div>
    </div>
  )
}

export default HomePage