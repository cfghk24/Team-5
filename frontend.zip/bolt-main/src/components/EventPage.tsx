import React from 'react'
import events from '../data/events.json'

interface EventPageProps {
  eventId: number;
  language: string;
}

const EventPage: React.FC<EventPageProps> = ({ eventId, language }) => {
  const event = events.find(e => e.id === eventId)

  if (!event) {
    return <div>Event not found</div>
  }

  const title = language === 'en' ? event.title : event.titleZh || event.title
  const description = language === 'en' ? event.description : event.descriptionZh || event.description

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-bold text-accent mb-6">{title}</h1>
      <p className="text-lg mb-4">{new Date(event.date).toLocaleDateString()}</p>
      <div className="mb-8">
        <img src={`/content-${event.id}.png`} alt={title} className="w-full h-64 object-cover rounded-lg" />
      </div>
      <div className="prose max-w-none">
        {description.split('\n').map((paragraph, index) => (
          <p key={index} className="mb-4">{paragraph}</p>
        ))}
      </div>
      <h2 className="text-2xl font-bold mt-8 mb-4">{language === 'en' ? 'Comments' : '评论'}</h2>
      <div className="space-y-4">
        {event.comments.map((comment, index) => (
          <div key={index} className="bg-white p-4 rounded-lg shadow">
            <p className="font-semibold">{comment.author}</p>
            <p>{comment.content}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

export default EventPage