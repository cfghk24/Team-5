import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

interface NavItem {
  icon: React.ReactNode;
  label: string;
  link: string;
  subItems?: string[];
  onClick?: (subItem?: string) => void;
}

interface NavbarProps {
  items: NavItem[];
}

const Navbar: React.FC<NavbarProps> = ({ items }) => {
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null);

  return (
    <nav className="w-64 bg-white shadow-lg">
      <div className="p-4">
        <h1 className="text-2xl font-bold text-[#4D869C]">
          <img src="/logo.png" alt="Aftec Logo" />
          Aftec
        </h1>
      </div>
      <ul>
        {items.map((item) => (
          <li key={item.label} className="mb-2">
            <a
              href="#"
              className="flex items-center px-4 py-2 text-gray-700 hover:bg-[#4D869C] hover:text-white transition-colors duration-200"
              onClick={(e) => {
                e.preventDefault();
                if (item.subItems) {
                  setOpenSubmenu(openSubmenu === item.label ? null : item.label);
                } else {
                  item.onClick?.();
                }
              }}
            >
              {item.icon}
              <span className="ml-2">{item.label}</span>
              {item.subItems && <ChevronDown size={16} className="ml-auto" />}
            </a>
            {item.subItems && openSubmenu === item.label && (
              <ul className="bg-gray-100 py-2">
                {item.subItems.map((subItem) => (
                  <li key={subItem}>
                    <a
                      href="#"
                      className="block px-8 py-2 text-sm text-gray-700 hover:bg-[#4D869C] hover:text-white transition-colors duration-200"
                      onClick={(e) => {
                        e.preventDefault();
                        item.onClick?.(subItem);
                        setOpenSubmenu(null);
                      }}
                    >
                      {subItem}
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Navbar;