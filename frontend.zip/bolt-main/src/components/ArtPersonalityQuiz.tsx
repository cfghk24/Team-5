import React, { useState } from 'react';
import games from '../data/games.json';

interface Choice {
  text: string;
  score: Record<string, number>;
}

interface Question {
  id: number;
  text: string;
  choices: Choice[];
}

interface Game {
  id: number;
  title: string;
  description: string;
  questions: Question[];
  results: Record<string, string>;
}

const ArtPersonalityQuiz: React.FC = () => {
  const [currentGame, setCurrentGame] = useState<Game | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [scores, setScores] = useState<Record<string, number>>({});
  const [result, setResult] = useState<string | null>(null);

  const startGame = (game: Game) => {
    setCurrentGame(game);
    setCurrentQuestion(0);
    setScores({});
    setResult(null);
  };

  const handleAnswer = (choice: Choice) => {
    const newScores = { ...scores };
    Object.entries(choice.score).forEach(([key, value]) => {
      newScores[key] = (newScores[key] || 0) + value;
    });
    setScores(newScores);

    if (currentQuestion < (currentGame?.questions.length || 0) - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      const maxScore = Math.max(...Object.values(newScores));
      const result = Object.keys(newScores).find(
        (key) => newScores[key] === maxScore
      );
      setResult(result || null);
    }
  };

  const resetQuiz = () => {
    setCurrentGame(null);
    setCurrentQuestion(0);
    setScores({});
    setResult(null);
  };

  if (!currentGame) {
    return (
      <div className="max-w-4xl mx-auto mt-8">
        <h2 className="text-3xl font-bold text-accent mb-6">Choose a Quiz</h2>
        <p style={{ color: 'red' }}>Complete to earn 20 points</p>
        <br />
        {games.map((game) => (
          <div key={game.id} className="mb-6 p-6 bg-white rounded-lg shadow-md">
            <h3 className="text-2xl font-semibold mb-2">{game.title}</h3>
            <p className="text-gray-600 mb-4">{game.description}</p>
            <button
              onClick={() => startGame(game)}
              className="bg-accent text-white px-4 py-2 rounded hover:bg-accent/80 transition-colors duration-200"
            >
              Start Quiz
            </button>
          </div>
        ))}
      </div>
    );
  }

  if (result) {
    return (
      <div className="max-w-4xl mx-auto mt-8 p-6 bg-white rounded-lg shadow-md">
        <h2 className="text-3xl font-bold text-accent mb-6">Your Result</h2>
        <p className="text-xl mb-6">
          {currentGame.results[result]}
          <br />
          <img src="/res.png" />
        </p>
        <button
          onClick={resetQuiz}
          className="bg-accent text-white px-4 py-2 rounded hover:bg-accent/80 transition-colors duration-200"
        >
          Take Another Quiz
        </button>
      </div>
    );
  }

  const question = currentGame.questions[currentQuestion];

  return (
    <div className="max-w-4xl mx-auto mt-8 p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-3xl font-bold text-accent mb-6">
        {currentGame.title}
      </h2>
      <p className="text-xl mb-6">
        Question {currentQuestion + 1} of {currentGame.questions.length}
      </p>
      <p className="text-lg mb-4">{question.text}</p>
      <div className="space-y-4">
        {question.choices.map((choice, index) => (
          <button
            key={index}
            onClick={() => handleAnswer(choice)}
            className="w-full text-left p-4 bg-gray-100 rounded hover:bg-gray-200 transition-colors duration-200"
          >
            {choice.text}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ArtPersonalityQuiz;
