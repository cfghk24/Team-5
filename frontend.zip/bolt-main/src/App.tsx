import React, { useState } from 'react'
import { Home, Calendar, Info, Mail, Heart, User, Globe, Gamepad2 } from 'lucide-react'
import Navbar from './components/Navbar'
import HomePage from './components/HomePage'
import ArtPersonalityQuiz from './components/ArtPersonalityQuiz'
import EventPage from './components/EventPage'

function App() {
  const [language, setLanguage] = useState('en')
  const [currentPage, setCurrentPage] = useState('home')
  const [currentEventId, setCurrentEventId] = useState<number | null>(null)

  const navItems = [
    { icon: <Home size={20} />, label: language === 'en' ? 'Home' : '首页', link: 'home', onClick: () => setCurrentPage('home') },
    { 
      icon: <Calendar size={20} />, 
      label: language === 'en' ? 'Events' : '活动', 
      link: 'events',
      subItems: language === 'en' 
        ? ['Current', 'Upcoming', 'Past', 'Custom Status']
        : ['当前', '即将到来', '过去', '自定义状态'],
      onClick: () => setCurrentPage('events')
    },
    { icon: <Info size={20} />, label: language === 'en' ? 'About Us' : '关于我们', link: 'about', onClick: () => setCurrentPage('about') },
    { icon: <Mail size={20} />, label: language === 'en' ? 'Contact Us' : '联系我们', link: 'contact', onClick: () => setCurrentPage('contact') },
    { icon: <Heart size={20} />, label: language === 'en' ? 'Donation' : '捐赠', link: 'donation', onClick: () => setCurrentPage('donation') },
    { icon: <Gamepad2 size={20} />, label: language === 'en' ? 'Art Quiz' : '艺术测验', link: 'game', onClick: () => setCurrentPage('game') },
    { icon: <User size={20} />, label: language === 'en' ? 'Profile' : '个人资料', link: 'profile', onClick: () => setCurrentPage('profile') },
  ]

  navItems.push({
    icon: <Globe size={20} />,
    label: language === 'en' ? 'Language' : '语言',
    link: '#',
    subItems: ['English', '中文'],
    onClick: (subItem: string) => setLanguage(subItem === 'English' ? 'en' : 'zh')
  })

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage language={language} onEventClick={(id: number) => { setCurrentEventId(id); setCurrentPage('event'); }} />;
      case 'game':
        return <ArtPersonalityQuiz />;
      case 'event':
        return currentEventId !== null ? <EventPage eventId={currentEventId} language={language} /> : null;
      case 'events':
        return <div className="p-4">Events page (to be implemented)</div>;
      case 'about':
        return <div className="p-4">About Us page (to be implemented)</div>;
      case 'contact':
        return <div className="p-4">Contact Us page (to be implemented)</div>;
      case 'donation':
        return <div className="p-4">Donation page (to be implemented)</div>;
      case 'profile':
        return <div className="p-4">Profile page (to be implemented)</div>;
      default:
        return <HomePage language={language} onEventClick={(id: number) => { setCurrentEventId(id); setCurrentPage('event'); }} />;
    }
  };

  return (
    <div className="flex h-screen bg-[#EEF7FF]">
      <Navbar items={navItems} />
      <main className="flex-1 p-8 overflow-auto">
        {renderPage()}
      </main>
    </div>
  )
}

export default App